﻿using Azure.Identity;
using Microsoft.Graph;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebTesteTeams
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            CreateMeetingTeamsTesteExterno().Wait();
        }


        #region CRUD TEAMS

        /// <summary>
        /// Autenticações Clientsecretcredential
        /// </summary>
        /// <returns></returns>
        public async Task<GraphServiceClient> createGraphServiceClient()
        {
            // The client credentials flow requires that you request the
            // /.default scope, and preconfigure your permissions on the
            // app registration in Azure. An administrator must grant consent
            // to those permissions beforehand.
            //ar scopes = "User.read Mail.Send Mail.ReadWrite OnlineMeetings.ReadWrite";
            var scopes = new[] { "https://graph.microsoft.com/.default" };

            // Multi-tenant apps can use "common",
            // single-tenant apps must use the tenant ID from the Azure portal
            var tenantId = "0e47a36f-2d92-4636-878a-1deb5f015132";

            // Values from app registration
            var clientId = "6aca6eb6-af12-40d4-9772-71f29f0be0fb";
            var clientSecret = "684d38f7-e093-4075-ae48-be7e3e313f4c";

            // using Azure.Identity;
            var options = new TokenCredentialOptions
            {
                AuthorityHost = AzureAuthorityHosts.AzurePublicCloud
            };
            try
            {
                //System.Text.Json
                // https://docs.microsoft.com/dotnet/api/azure.identity.clientsecretcredential
                var clientSecretCredential = new ClientSecretCredential(
                    tenantId, clientId, clientSecret, options);
                var graphClient = new GraphServiceClient(clientSecretCredential, scopes);
                return graphClient;
            }
            catch (Exception erro)
            {

                return null;
            }

        }

        public OnlineMeeting CreateTeamsMeeting(
        string meeting, DateTimeOffset begin, DateTimeOffset end)
        {

            var onlineMeeting = new OnlineMeeting
            {
                StartDateTime = begin,
                EndDateTime = end,
                Subject = meeting,
                LobbyBypassSettings = new LobbyBypassSettings
                {
                    Scope = LobbyBypassScope.Everyone
                }
            };

            return onlineMeeting;
        }

        /// <summary>
        /// role
        /// Participante = Attendee = 0,
        /// Apresentadora = Presenter = 1,                     
        /// Valor futuro desconhecido  = UnknownFutureValue = 2,
        /// Produtora = Producer = 3
        /// </summary>
        /// <param name="onlineMeeting"></param>
        /// <param name="attendees"></param>
        /// <param name="role"></param>
        /// <returns></returns>
        public OnlineMeeting AddMeetingParticipants(
    OnlineMeeting onlineMeeting, List<string> attendees, OnlineMeetingRole role = OnlineMeetingRole.Attendee)
        {

            var MeetingRole = OnlineMeetingRole.Attendee;

            //switch (role)
            //{
            //    case 0:
            //    default:
            //        MeetingRole = OnlineMeetingRole.Attendee;
            //        break;

            //    case 1:
            //        MeetingRole = OnlineMeetingRole.Presenter;
            //        break;

            //    case 2:
            //        MeetingRole = OnlineMeetingRole.UnknownFutureValue;
            //        break;

            //    case 3:
            //        MeetingRole = OnlineMeetingRole.Producer;
            //        break;
            //}

            var meetingAttendees = new List<MeetingParticipantInfo>();
            foreach (var attendee in attendees)
            {
                if (!string.IsNullOrEmpty(attendee))
                {
                    meetingAttendees.Add(new MeetingParticipantInfo
                    {
                        Upn = attendee.Trim(),
                        ///Participante = Attendee = 0,
                        ///Apresentadora = Presenter = 1,                     
                        ///Valor futuro desconhecido  = UnknownFutureValue = 2,
                        ///Produtora = Producer = 3
                        Role = role
                    });
                }
            }

            if (onlineMeeting.Participants == null)
            {
                onlineMeeting.Participants = new MeetingParticipants();
            };

            onlineMeeting.Participants.Attendees = meetingAttendees;

            return onlineMeeting;
        }

        /// <summary>
        /// JoinUrl = createdMeeting.JoinUrl;
        /// </summary>
        /// <param name="onlineMeeting"></param>
        /// <returns></returns>
        public async Task<OnlineMeeting> CreateOnlineMeeting(
    OnlineMeeting onlineMeeting)
        {
            var _graphServiceClient = await createGraphServiceClient();

            try
            {

                 await _graphServiceClient.Me
                    .OnlineMeetings
                    .Request()
                    .AddAsync(onlineMeeting);

            }
            catch (Exception erro)
            {


            }

            return null;
        }

        public async Task<OnlineMeeting> UpdateOnlineMeeting(
            OnlineMeeting onlineMeeting)
        {
            var _graphServiceClient = await createGraphServiceClient();
            return await _graphServiceClient.Me
                .OnlineMeetings[onlineMeeting.Id]
                .Request()
                .UpdateAsync(onlineMeeting);
        }

        public async Task<OnlineMeeting> GetOnlineMeeting(
            string onlineMeetingId)
        {
            var _graphServiceClient = await createGraphServiceClient();
            return await _graphServiceClient.Me
                .OnlineMeetings[onlineMeetingId]
                .Request()
                .GetAsync();
        }

        public async Task<IMeetingAttendanceReportAttendanceRecordsCollectionPage> GetPresenceOnlineMeeting(
         string onlineMeetingId)
        {
            var _graphServiceClient = await createGraphServiceClient();
            var attendanceReports = await _graphServiceClient.Me.OnlineMeetings["{onlineMeeting-id}"].AttendanceReports
                .Request().Expand("AttendanceRecords")
                .GetAsync() as IMeetingAttendanceReportAttendanceRecordsCollectionPage;

            //        var attendanceRecords = await _graphServiceClient.Me.OnlineMeetings[onlineMeetingId].AttendanceReports["{meetingAttendanceReport-id}"].AttendanceRecords
            //    .Request()
            //    .GetAsync();

            //        var presence = await _graphServiceClient.Users["{user-id}"].Presence
            //.Request()
            //.GetAsync();

            return attendanceReports;
        }

        #endregion


        /// <summary>
        /// Teste Externo
        /// </summary>
        /// <param name="onlineMeeting"></param>
        /// <returns></returns>
        public async Task CreateMeetingTeamsTesteExterno()
        {
            OnlineMeeting onlineMeeting = new OnlineMeeting
            {
                StartDateTime = DateTimeOffset.Parse("2022-11-21T17:30:34.2444915+00:00"),
                EndDateTime = DateTimeOffset.Parse("2022-11-21T18:30:34.2444915+00:00"),
                Subject = "Reunião de teste Valdir",
            };

            var newOnlineMeeting = await CreateOnlineMeeting(onlineMeeting);

            var instrutores = new List<string>();
            instrutores.Add("valdir.silva@micropowerglobal.com");
            AddMeetingParticipants(newOnlineMeeting, instrutores, OnlineMeetingRole.Presenter);


            var participantes = new List<string>();
            participantes.Add("valdirferreira2006@gmail.com");
            AddMeetingParticipants(newOnlineMeeting, participantes, OnlineMeetingRole.Attendee);


            // Atualiza
            await UpdateOnlineMeeting(newOnlineMeeting);

            // Obter reunião online
            var OnlineMeetingObtida = await GetOnlineMeeting(newOnlineMeeting.Id);

            // Lista Presenças
            var listaPresenca = await GetPresenceOnlineMeeting(newOnlineMeeting.Id);


            //SysEventLog.DirectLog(LogEvent.MplsMonitor, string.Format("{0}: {1}", "Teams Creating Meeting API", $"Teams meeting sucessfully created. Start: {startDate.ToString("dd/MM/yyyy HH:mm")}. End: {endDate.ToString("dd/MM/yyyy HH:mm")}. Subject: {subject}. Description: {description}. User: {(IsInstructorMeetingHost ? email : AccountEmail)}"));
            //return new NewMeetingResult()
            //{
            //    joinURL = JsonConvert.DeserializeObject<JToken>(response.Content).SelectToken("join_url").ToString(),
            //    Id = Int64.Parse(JsonConvert.DeserializeObject<JToken>(response.Content).SelectToken("id").ToString()),
            //    startURL = JsonConvert.DeserializeObject<JToken>(response.Content).SelectToken("start_url").ToString(),
            //    UUID = JsonConvert.DeserializeObject<JToken>(response.Content).SelectToken("uuid").ToString(),
            //};

        }

        public async void CreateOnlineMeetings()
        {

            // The client credentials flow requires that you request the
            // /.default scope, and preconfigure your permissions on the
            // app registration in Azure. An administrator must grant consent
            // to those permissions beforehand.
            var scopes = new[] { "https://graph.microsoft.com/.default" };

            // Multi-tenant apps can use "common",
            // single-tenant apps must use the tenant ID from the Azure portal
            var tenantId = "common";

            // Values from app registration
            var clientId = "YOUR_CLIENT_ID";
            var clientSecret = "YOUR_CLIENT_SECRET";

            // using Azure.Identity;
            var options = new TokenCredentialOptions
            {
                AuthorityHost = AzureAuthorityHosts.AzurePublicCloud
            };

            // https://docs.microsoft.com/dotnet/api/azure.identity.clientsecretcredential
            var clientSecretCredential = new ClientSecretCredential(
                tenantId, clientId, clientSecret, options);

            var graphClient = new GraphServiceClient(clientSecretCredential, scopes);


            //GraphServiceClient graphClient = new GraphServiceClient(authProvider);

            var onlineMeeting = new OnlineMeeting
            {
                StartDateTime = DateTimeOffset.Parse("2019-07-12T21:30:34.2444915+00:00"),
                EndDateTime = DateTimeOffset.Parse("2019-07-12T22:00:34.2464912+00:00"),
                Subject = "User Token Meeting",


            };

            var meetingParticipants = new MeetingParticipants();

            //var Organizer = new MeetingParticipantInfo();

            var Attendees = new List<MeetingParticipantInfo>();

            Attendees.Add(new MeetingParticipantInfo
            {
                //Identity = ""
                Identity = new IdentitySet { User = new Identity { DisplayName = "" } },
                Upn = "Nome principal do participante",

                // Participante
                //Attendee = 0,

                // Apresentadora    
                // Presenter = 1,

                //Valor futuro desconhecido     
                //UnknownFutureValue = 2,

                // Summary:
                //Produtora

                Role = OnlineMeetingRole.Presenter
            });


            var response = await graphClient.Me.OnlineMeetings
                .Request()
                .AddAsync(onlineMeeting);


            // Criando um evento 
            var @event = new Event
            {
                Subject = "Let's go for lunch",
                Body = new ItemBody
                {
                    ContentType = BodyType.Html,
                    Content = "Does noon work for you?"
                },
                Start = new DateTimeTimeZone
                {
                    DateTime = "2017-04-15T12:00:00",
                    TimeZone = "Pacific Standard Time"
                },
                End = new DateTimeTimeZone
                {
                    DateTime = "2017-04-15T14:00:00",
                    TimeZone = "Pacific Standard Time"
                },
                Location = new Location
                {
                    DisplayName = "Harry's Bar"
                },
                Attendees = new List<Attendee>()
                    {
                        new Attendee
                        {
                            EmailAddress = new EmailAddress
                            {
                                Address = "samanthab@contoso.onmicrosoft.com",
                                Name = "Samantha Booth"
                            },
                            Type = AttendeeType.Required
                        }
                    },
                Organizer = new Recipient
                {
                    EmailAddress = new EmailAddress
                    {
                        Name = "Tutor",
                        Address = "tutor@email.com"
                    }
                },

                AllowNewTimeProposals = true,
                IsOnlineMeeting = true,
                OnlineMeetingProvider = OnlineMeetingProviderType.TeamsForBusiness
            };

            await graphClient.Me.Events
                .Request()
                .Header("Prefer", "outlook.timezone=\"Pacific Standard Time\"")
                .AddAsync(@event);



            // Obter um evento 
            var eventoObtido = await graphClient.Me.Events["{event-id}"]
    .Request()
    .Header("Prefer", "outlook.timezone=\"Pacific Standard Time\"")
    // .Select("subject,body,bodyPreview,organizer,attendees,start,end,location,hideAttendees")
    .GetAsync();



            // Atualiza um evento
            var newAttendees = new List<Attendee>();

            foreach (var Attendee in eventoObtido.Attendees)
            {
                newAttendees.Add(Attendee);
            }

            newAttendees.Add(new Attendee
            {
                EmailAddress = new EmailAddress
                {
                    Address = "samanthab@contoso.onmicrosoft.com",
                    Name = "Samantha Booth"
                },
                Type = AttendeeType.Required
            });

            await graphClient.Me.Events["{event-id}"]
            .Request()
            .UpdateAsync(eventoObtido);



        }



    }
}