﻿using Azure.Core;
using Azure.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Graph;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using WebNEtTeams.Models;

namespace WebNEtTeams.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {

            await CreateMeetingTeamsTesteExterno();

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }




        #region CRUD TEAMS

        /// <summary>
        /// Autenticações Clientsecretcredential
        /// </summary>
        /// <returns></returns>
        public async Task<GraphServiceClient> createGraphServiceClient()
        {
            // The client credentials flow requires that you request the
            // /.default scope, and preconfigure your permissions on the
            // app registration in Azure. An administrator must grant consent
            // to those permissions beforehand.
            //var scopes = "User.read Mail.Send Mail.ReadWrite OnlineMeetings.ReadWrite";
            var scopes = new[] { "https://graph.microsoft.com/.default" };

            // Multi-tenant apps can use "common",
            // single-tenant apps must use the tenant ID from the Azure portal
            //var tenantId = "96f70846-5bc8-429d-8ab3-85b9e5d1c9e1";

            //// Values from app registration
            //var clientId = "ddce009d-3995-4cda-8ad4-9d1a4ec54031";
            //var clientSecret = "cNm8Q~N2hsNCCmc1ztDkDn6nb3q8hezKx8bCkaN5";

            //            App Performa_Teams_v2

            //App ID: 3232ced0-164d-4213-982b-6b27e7c6dc2a

            //Tenant ID: 0e47a36f-2d92-4636-878a-1deb5f015132

            //ID Secret: 5e590d89-0f67-4a18-b77b-8a66c57a3728

            //Value Secret: JIV8Q~xgetyA8fhxXPQzykBUlkghPlROgIhWYadW


            var tenantId = "0e47a36f-2d92-4636-878a-1deb5f015132";
            var clientId = "3232ced0-164d-4213-982b-6b27e7c6dc2a";
            var clientSecret = "JIV8Q~xgetyA8fhxXPQzykBUlkghPlROgIhWYadW";

            // using Azure.Identity;
            var options = new TokenCredentialOptions
            {
                AuthorityHost = AzureAuthorityHosts.AzurePublicCloud,
            };
            try
            {
                //System.Text.Json
                // https://docs.microsoft.com/dotnet/api/azure.identity.clientsecretcredential
                var clientSecretCredential = new ClientSecretCredential(
                    tenantId, clientId, clientSecret, options);
                //var tokenRequestContext = new TokenRequestContext(scopes);
                //var token = clientSecretCredential.GetTokenAsync(tokenRequestContext).Result.Token;
                var graphClient = new GraphServiceClient(clientSecretCredential, scopes);

                return graphClient;
            }
            catch (Exception erro)
            {

                return null;
            }

        }

        public OnlineMeeting CreateTeamsMeeting(
        string meeting, DateTimeOffset begin, DateTimeOffset end)
        {

            var onlineMeeting = new OnlineMeeting
            {
                StartDateTime = begin,
                EndDateTime = end,
                Subject = meeting,
                LobbyBypassSettings = new LobbyBypassSettings
                {
                    Scope = LobbyBypassScope.Everyone
                }
            };

            return onlineMeeting;
        }

        /// <summary>
        /// role
        /// Participante = Attendee = 0,
        /// Apresentadora = Presenter = 1,                     
        /// Valor futuro desconhecido  = UnknownFutureValue = 2,
        /// Produtora = Producer = 3
        /// </summary>
        /// <param name="onlineMeeting"></param>
        /// <param name="attendees"></param>
        /// <param name="role"></param>
        /// <returns></returns>
        public OnlineMeeting AddMeetingParticipants(
    OnlineMeeting onlineMeeting, List<string> attendees, OnlineMeetingRole role = OnlineMeetingRole.Attendee)
        {

            var MeetingRole = OnlineMeetingRole.Attendee;

            var meetingAttendees = new List<MeetingParticipantInfo>();
            foreach (var attendee in attendees)
            {
                if (!string.IsNullOrEmpty(attendee))
                {
                    meetingAttendees.Add(new MeetingParticipantInfo
                    {
                        Upn = attendee.Trim(),
                        ///Participante = Attendee = 0,
                        ///Apresentadora = Presenter = 1,                     
                        ///Valor futuro desconhecido  = UnknownFutureValue = 2,
                        ///Produtora = Producer = 3
                        Role = role
                    });
                }
            }

            if (onlineMeeting.Participants == null)
            {
                onlineMeeting.Participants = new MeetingParticipants();
            }
            else
            {
                foreach (var attendee in onlineMeeting.Participants.Attendees)
                {
                    meetingAttendees.Add(attendee);
                }
            }

            onlineMeeting.Participants.Attendees = meetingAttendees;

            return onlineMeeting;
        }

        public OnlineMeeting AddMeetingParticipants_ADD(
OnlineMeeting onlineMeeting, List<string> attendees, OnlineMeetingRole role = OnlineMeetingRole.Attendee)
        {

            var MeetingRole = OnlineMeetingRole.Attendee;

            var meetingAttendees = new List<MeetingParticipantInfo>();
            foreach (var attendee in attendees)
            {
                if (!string.IsNullOrEmpty(attendee))
                {
                    meetingAttendees.Add(new MeetingParticipantInfo
                    {
                        Upn = attendee.Trim(),
                        ///Participante = Attendee = 0,
                        ///Apresentadora = Presenter = 1,                     
                        ///Valor futuro desconhecido  = UnknownFutureValue = 2,
                        ///Produtora = Producer = 3
                        Role = role
                    });
                }
            }

            if (onlineMeeting.Participants == null)
            {
                onlineMeeting.Participants = new MeetingParticipants();
            }
            else
            {
                onlineMeeting.Participants.Organizer = null;

                foreach (var attendee in onlineMeeting.Participants.Attendees)
                {
                    meetingAttendees.Add(attendee);
                }
            }

            onlineMeeting.Participants.Attendees = meetingAttendees;

            return onlineMeeting;
        }

        /// <summary>
        /// JoinUrl = createdMeeting.JoinUrl;
        /// </summary>
        /// <param name="onlineMeeting"></param>
        /// <returns></returns>
        public async Task<OnlineMeeting> CreateOnlineMeeting(
    OnlineMeeting onlineMeeting)
        {
            var _graphServiceClient = await createGraphServiceClient();


            try
            {
                var userId = await GetUserIdAsync();

                var onlineMeetingRetorno = await _graphServiceClient.Users[userId]
                          .OnlineMeetings
                      .Request()
                      .AddAsync(onlineMeeting);

                //await _graphServiceClient.Me
                //       .OnlineMeetings
                //   .Request()
                //   .AddAsync(onlineMeeting);

                return onlineMeetingRetorno;

            }
            catch (Exception erro)
            {
            }
            return null;
        }


        private async Task<string> GetUserIdAsync()
        {
            try
            {
                var meetingOrganizer = "valdir.silva@micropower.com.br";
                var filter = $"startswith(userPrincipalName,'{meetingOrganizer}')";
                var _graphServiceClient = await createGraphServiceClient();

                var users = await _graphServiceClient.Users
                    .Request()
                    .Filter(filter)
                    .GetAsync();

                return users.CurrentPage[0].Id;
            }
            catch (Exception err)
            {

            }

            return string.Empty;
        }

        public async Task<OnlineMeeting> UpdateOnlineMeeting(
            OnlineMeeting onlineMeeting)
        {
            try
            {

                var userId = await GetUserIdAsync();
                var _graphServiceClient = await createGraphServiceClient();

                OnlineMeeting updateOnlineMeeting = new OnlineMeeting
                {
                };

                #region Primeiro Instrutor
                var OnlineMeetingObtidaOne = await GetOnlineMeeting(onlineMeeting.Id);
                updateOnlineMeeting.Participants = OnlineMeetingObtidaOne.Participants;

                var instrutores = new List<string>();
                instrutores.Add("valdir.silva@micropowerglobal.com");
                AddMeetingParticipants_ADD(updateOnlineMeeting, instrutores, OnlineMeetingRole.Presenter);

                var updateOnlineMeetingUpdateSucess = await _graphServiceClient.Users[userId]
                    .OnlineMeetings[onlineMeeting.Id]
                    .Request()
                    .UpdateAsync(updateOnlineMeeting);
                #endregion

                #region Segundo Aluno
                OnlineMeeting updateOnlineMeetingTwo = new OnlineMeeting
                {
                };

                var OnlineMeetingObtidaTwo = await GetOnlineMeeting(onlineMeeting.Id);
                updateOnlineMeetingTwo.Participants = OnlineMeetingObtidaTwo.Participants;

                var participantes = new List<string>();
                participantes.Add("elias.paula@micropowerglobal.com");
                AddMeetingParticipants_ADD(updateOnlineMeetingTwo, participantes, OnlineMeetingRole.Attendee);

                var updateOnlineMeetingUpdateSucess2 = await _graphServiceClient.Users[userId]
                  .OnlineMeetings[onlineMeeting.Id]
                  .Request()
                  .UpdateAsync(updateOnlineMeetingTwo);
                #endregion


                OnlineMeeting updateOnlineMeetingThree = new OnlineMeeting
                {
                };

                var OnlineMeetingObtidaThree = await GetOnlineMeeting(onlineMeeting.Id);
                updateOnlineMeetingThree.Participants = OnlineMeetingObtidaThree.Participants;

                var participantes2 = new List<string>();
                participantes2.Add("valdirferreira2006@hotmail.com");
                AddMeetingParticipants_ADD(updateOnlineMeetingThree, participantes2, OnlineMeetingRole.Attendee);


                var updateOnlineMeetingUpdateSucess3 = await _graphServiceClient.Users[userId]
                  .OnlineMeetings[onlineMeeting.Id]
                  .Request()
                  .UpdateAsync(updateOnlineMeetingThree);


                var attendanceReports = await _graphServiceClient.Users[userId].OnlineMeetings[onlineMeeting.Id].AttendanceReports
    .Request()
    .GetAsync();

                var listMeetingAttendanceReport = new List<MeetingAttendanceReport>();

                var listTeamsTimeUser = new List<TeamsTimeUser>();

                foreach (var item in attendanceReports.CurrentPage)
                {
                    var meetingAttendanceReport = await _graphServiceClient.Users[userId]
                    .OnlineMeetings[onlineMeeting.Id].AttendanceReports[item.Id]
                    .Request()
                    .Expand("attendanceRecords")
                    .GetAsync();

                    listTeamsTimeUser.Add(new TeamsTimeUser
                    {
                        MeetingStartDateTime = meetingAttendanceReport.MeetingStartDateTime.Value.UtcDateTime,
                        MeetingEndDateTime = meetingAttendanceReport.MeetingEndDateTime.Value.UtcDateTime,

                        EmailAddress = meetingAttendanceReport.AttendanceRecords.CurrentPage.FirstOrDefault().EmailAddress,
                        IdUser = meetingAttendanceReport.AttendanceRecords.CurrentPage.FirstOrDefault().Id,
                        TotalAttendanceInSeconds =
                   meetingAttendanceReport.AttendanceRecords.CurrentPage.FirstOrDefault().TotalAttendanceInSeconds != null
                   ? meetingAttendanceReport.AttendanceRecords.CurrentPage.FirstOrDefault().TotalAttendanceInSeconds.Value : 0
                    });

                }

               var  teamsMeetingPresenceList = AdjustAttendanceTeams(listTeamsTimeUser);

                return updateOnlineMeetingUpdateSucess;

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<OnlineMeeting> GetOnlineMeeting(
            string onlineMeetingId)
        {

            var userId = await GetUserIdAsync();

            var _graphServiceClient = await createGraphServiceClient();
            return await _graphServiceClient.Users[userId]
                .OnlineMeetings[onlineMeetingId]
                .Request()
                .GetAsync();
        }



        public async Task<object> GetPresenceOnlineMeeting(
         string onlineMeetingId)
        {

            try
            {

                var userId = await GetUserIdAsync();

                var _graphServiceClient = await createGraphServiceClient();
                //var attendanceReports = await _graphServiceClient.Users[userId].OnlineMeetings["{onlineMeeting-id}"].AttendanceReports
                //    .Request().Expand("AttendanceRecords")
                //    .GetAsync() as IMeetingAttendanceReportAttendanceRecordsCollectionPage;

                var attendanceRecords = await _graphServiceClient.Users[userId].OnlineMeetings[onlineMeetingId].AttendanceReports["{meetingAttendanceReport-id}"].AttendanceRecords
            .Request()
            .GetAsync();

                //        var presence = await _graphServiceClient.Users["{user-id}"].Presence
                //.Request()
                //.GetAsync();

                return attendanceRecords;

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        #endregion


        /// <summary>
        /// Teste Externo
        /// </summary>
        /// <param name="onlineMeeting"></param>
        /// <returns></returns>
        public async Task CreateMeetingTeamsTesteExterno()
        {
            OnlineMeeting onlineMeeting = new OnlineMeeting
            {
                StartDateTime = DateTimeOffset.Parse("2022-11-30T17:30:34.2444915+00:00"),
                EndDateTime = DateTimeOffset.Parse("2022-11-30T18:30:34.2444915+00:00"),
                Subject = "Reunião de teste Valdir dia 30",

            };

            var newOnlineMeeting = await CreateOnlineMeeting(onlineMeeting);

            // Atualiza
            await UpdateOnlineMeeting(newOnlineMeeting);

            // Obter reunião online
            var OnlineMeetingObtida = await GetOnlineMeeting(newOnlineMeeting.Id);

            // Lista Presenças
            var listaPresenca = await GetPresenceOnlineMeeting(newOnlineMeeting.Id);


            //SysEventLog.DirectLog(LogEvent.MplsMonitor, string.Format("{0}: {1}", "Teams Creating Meeting API", $"Teams meeting sucessfully created. Start: {startDate.ToString("dd/MM/yyyy HH:mm")}. End: {endDate.ToString("dd/MM/yyyy HH:mm")}. Subject: {subject}. Description: {description}. User: {(IsInstructorMeetingHost ? email : AccountEmail)}"));
            //return new NewMeetingResult()
            //{
            //    joinURL = JsonConvert.DeserializeObject<JToken>(response.Content).SelectToken("join_url").ToString(),
            //    Id = Int64.Parse(JsonConvert.DeserializeObject<JToken>(response.Content).SelectToken("id").ToString()),
            //    startURL = JsonConvert.DeserializeObject<JToken>(response.Content).SelectToken("start_url").ToString(),
            //    UUID = JsonConvert.DeserializeObject<JToken>(response.Content).SelectToken("uuid").ToString(),
            //};

        }

        public async void CreateOnlineMeetings()
        {

            // The client credentials flow requires that you request the
            // /.default scope, and preconfigure your permissions on the
            // app registration in Azure. An administrator must grant consent
            // to those permissions beforehand.
            var scopes = new[] { "https://graph.microsoft.com/.default" };

            // Multi-tenant apps can use "common",
            // single-tenant apps must use the tenant ID from the Azure portal
            var tenantId = "common";

            // Values from app registration
            var clientId = "YOUR_CLIENT_ID";
            var clientSecret = "YOUR_CLIENT_SECRET";

            // using Azure.Identity;
            var options = new TokenCredentialOptions
            {
                AuthorityHost = AzureAuthorityHosts.AzurePublicCloud
            };

            // https://docs.microsoft.com/dotnet/api/azure.identity.clientsecretcredential
            var clientSecretCredential = new ClientSecretCredential(
                tenantId, clientId, clientSecret, options);

            var graphClient = new GraphServiceClient(clientSecretCredential, scopes);


            //GraphServiceClient graphClient = new GraphServiceClient(authProvider);

            var onlineMeeting = new OnlineMeeting
            {
                StartDateTime = DateTimeOffset.Parse("2019-07-12T21:30:34.2444915+00:00"),
                EndDateTime = DateTimeOffset.Parse("2019-07-12T22:00:34.2464912+00:00"),
                Subject = "User Token Meeting",


            };

            var meetingParticipants = new MeetingParticipants();

            //var Organizer = new MeetingParticipantInfo();

            var Attendees = new List<MeetingParticipantInfo>();

            Attendees.Add(new MeetingParticipantInfo
            {
                //Identity = ""
                Identity = new IdentitySet { User = new Identity { DisplayName = "" } },
                Upn = "Nome principal do participante",

                // Participante
                //Attendee = 0,

                // Apresentadora    
                // Presenter = 1,

                //Valor futuro desconhecido     
                //UnknownFutureValue = 2,

                // Summary:
                //Produtora

                Role = OnlineMeetingRole.Presenter
            });


            var response = await graphClient.Me.OnlineMeetings
                .Request()
                .AddAsync(onlineMeeting);


            // Criando um evento 
            var @event = new Event
            {
                Subject = "Let's go for lunch",
                Body = new ItemBody
                {
                    ContentType = BodyType.Html,
                    Content = "Does noon work for you?"
                },
                Start = new DateTimeTimeZone
                {
                    DateTime = "2017-04-15T12:00:00",
                    TimeZone = "Pacific Standard Time"
                },
                End = new DateTimeTimeZone
                {
                    DateTime = "2017-04-15T14:00:00",
                    TimeZone = "Pacific Standard Time"
                },
                Location = new Location
                {
                    DisplayName = "Harry's Bar"
                },
                Attendees = new List<Attendee>()
                    {
                        new Attendee
                        {
                            EmailAddress = new EmailAddress
                            {
                                Address = "samanthab@contoso.onmicrosoft.com",
                                Name = "Samantha Booth"
                            },
                            Type = AttendeeType.Required
                        }
                    },
                Organizer = new Recipient
                {
                    EmailAddress = new EmailAddress
                    {
                        Name = "Tutor",
                        Address = "tutor@email.com"
                    }
                },

                AllowNewTimeProposals = true,
                IsOnlineMeeting = true,
                OnlineMeetingProvider = OnlineMeetingProviderType.TeamsForBusiness
            };

            await graphClient.Me.Events
                .Request()
                .Header("Prefer", "outlook.timezone=\"Pacific Standard Time\"")
                .AddAsync(@event);



            // Obter um evento 
            var eventoObtido = await graphClient.Me.Events["{event-id}"]
    .Request()
    .Header("Prefer", "outlook.timezone=\"Pacific Standard Time\"")
    // .Select("subject,body,bodyPreview,organizer,attendees,start,end,location,hideAttendees")
    .GetAsync();



            // Atualiza um evento
            var newAttendees = new List<Attendee>();

            foreach (var Attendee in eventoObtido.Attendees)
            {
                newAttendees.Add(Attendee);
            }

            newAttendees.Add(new Attendee
            {
                EmailAddress = new EmailAddress
                {
                    Address = "samanthab@contoso.onmicrosoft.com",
                    Name = "Samantha Booth"
                },
                Type = AttendeeType.Required
            });

            await graphClient.Me.Events["{event-id}"]
            .Request()
            .UpdateAsync(eventoObtido);



        }



        public List<TeamsMeetingPresenceList> AdjustAttendanceTeams(List<TeamsTimeUser> listTeamsTimeUser)
        {

            var returnList = new List<TeamsMeetingPresenceList>();

            var UsersMeeting = listTeamsTimeUser.Select(x => x.IdUser).Distinct();

            foreach (var IdUserMeeting in UsersMeeting)
            {
                returnList.Add(new TeamsMeetingPresenceList
                {
                    JoinTime = listTeamsTimeUser.Where(x => x.IdUser.Equals(IdUserMeeting)).Min(x => x.MeetingStartDateTime),
                    LeaveTime = listTeamsTimeUser.Where(x => x.IdUser.Equals(IdUserMeeting)).Max(x => x.MeetingEndDateTime),
                    Duration = listTeamsTimeUser.Where(x => x.IdUser.Equals(IdUserMeeting)).Sum(x => x.TotalAttendanceInSeconds),
                    Email = listTeamsTimeUser.FirstOrDefault(x => x.IdUser.Equals(IdUserMeeting)).EmailAddress,
                    UserName = listTeamsTimeUser.FirstOrDefault(x => x.IdUser.Equals(IdUserMeeting)).EmailAddress
                });
            }

            return returnList;

        }

    }


    public class TeamsTimeUser
    {
        public DateTime MeetingStartDateTime { get; set; }
        public DateTime MeetingEndDateTime { get; set; }
        public string EmailAddress { get; set; }
        public string IdUser { get; set; }
        public int TotalAttendanceInSeconds { get; set; }
    }

    public class TeamsMeetingPresenceList
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public int Duration { get; set; }
        public DateTime JoinTime { get; set; }
        public DateTime LeaveTime { get; set; }
    }

}
